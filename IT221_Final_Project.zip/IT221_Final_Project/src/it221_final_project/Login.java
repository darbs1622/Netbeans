package it221_final_project;

import javax.swing.*;
import java.awt.*;

public class Login extends JFrame {

    private JTextField emailField;
    private JPasswordField passwordField;

    public Login() {
        initUI();
    }

    private void initUI() {

        setTitle("Login | EventRides PH");
        setSize(500, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(248, 250, 252));

        // ================= CARD =================
        JPanel card = new JPanel();
        card.setLayout(null);
        card.setBounds(50, 60, 380, 450);
        card.setBackground(Color.WHITE);
        add(card);

        // ================= BACK BUTTON =================
        JButton backBtn = new JButton("← Back");
        backBtn.setBounds(10, 10, 100, 25);
        backBtn.setFocusPainted(false);
        backBtn.setBorderPainted(false);
        backBtn.setContentAreaFilled(false);
        backBtn.setForeground(new Color(100, 116, 139));
        card.add(backBtn);

        backBtn.addActionListener(e -> {
            new Index().setVisible(true); // ✅ FIXED
            dispose();
        });

        // ================= LOGO =================
        JLabel logo = new JLabel("EventRides PH", SwingConstants.CENTER);
        logo.setBounds(0, 50, 380, 30);
        logo.setFont(new Font("Arial", Font.BOLD, 20));
        logo.setForeground(new Color(79, 70, 229));
        card.add(logo);

        // ================= TITLE =================
        JLabel title = new JLabel("Welcome Back", SwingConstants.CENTER);
        title.setBounds(0, 90, 380, 25);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        card.add(title);

        // ================= EMAIL =================
        JLabel emailLabel = new JLabel("Email Address");
        emailLabel.setBounds(30, 140, 300, 20);
        emailLabel.setForeground(new Color(100, 116, 139));
        card.add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(30, 160, 320, 40);
        card.add(emailField);

        // ================= PASSWORD =================
        JLabel passLabel = new JLabel("Password");
        passLabel.setBounds(30, 220, 300, 20);
        passLabel.setForeground(new Color(100, 116, 139));
        card.add(passLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(30, 240, 320, 40);
        card.add(passwordField);

        // ================= LOGIN BUTTON =================
        JButton loginBtn = new JButton("Sign In");
        loginBtn.setBounds(30, 310, 320, 45);
        loginBtn.setBackground(new Color(79, 70, 229));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        card.add(loginBtn);

        loginBtn.addActionListener(e -> {
            String email = emailField.getText();
            String pass = new String(passwordField.getPassword());

            if (email.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields!");
                return;
            }

            loginBtn.setText("Signing in...");
            loginBtn.setEnabled(false);

            // Simulation of authentication process
            Timer t = new Timer(1000, ev -> {
                // Logic to transition to the Dashboard
                dispose(); // Close the Login window
                
                // Create and display the Dashboard
                Dashboard dash = new Dashboard();
                dash.revalidate(); // Ensures layout is calculated
                dash.repaint();    // Refreshes the visuals
                dash.setVisible(true);
            });

            t.setRepeats(false);
            t.start();
        });

        // ================= SIGNUP TEXT =================
        JLabel signupText = new JLabel("Don't have an account?", SwingConstants.CENTER);
        signupText.setBounds(30, 370, 320, 25);
        signupText.setForeground(new Color(100, 116, 139));
        card.add(signupText);

        // ================= SIGNUP BUTTON =================
        JButton signupBtn = new JButton("Create One");
        signupBtn.setBounds(30, 400, 320, 35);
        signupBtn.setForeground(new Color(79, 70, 229));
        signupBtn.setFocusPainted(false);
        card.add(signupBtn);

        signupBtn.addActionListener(e -> {
            new Signup().setVisible(true); // ✅ FIXED (was Index)
            dispose();
        });

       setVisible(true);
    }
}