package it221_final_project;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Payments extends JFrame {

    public Payments() {
        createUI();
    }

    private void createUI() {
        // ================= FRAME CONFIGURATION =================
        setTitle("EventRides PH | Payment Management");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null); 
        getContentPane().setBackground(new Color(223, 232, 242));

        // ================= SIDEBAR =================
        // Consistent 260px width and dark slate color
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setBounds(0, 0, 260, 700);
        sidebar.setBackground(new Color(15, 23, 42));
        add(sidebar);

        JLabel brand = new JLabel("EventRides PH");
        brand.setBounds(20, 30, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Arial", Font.BOLD, 18));
        sidebar.add(brand);

        String[] menu = {"Dashboard", "Rentals", "Inventory", "Customers", "Payments", "Settings"};
        int y = 100;
        for (String item : menu) {
            JButton btn = new JButton(item);
            btn.setBounds(20, y, 200, 40);
            btn.setFocusPainted(false);
            btn.setBackground(new Color(30, 41, 59));
            btn.setForeground(Color.WHITE);
            
            // Highlight active page with Indigo[cite: 2]
            if(item.equals("Payments")) btn.setBackground(new Color(79, 70, 229));

            btn.addActionListener(e -> navigateTo(btn.getText()));
            sidebar.add(btn);
            y += 50;
        }

        // ================= MAIN CONTENT AREA =================
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBounds(260, 0, 940, 700);
        content.setBackground(new Color(223, 232, 242));
        add(content);

        JLabel title = new JLabel("Payment Management");
        title.setBounds(30, 20, 300, 30);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        content.add(title);

        // ================= FINANCIAL SUMMARY CARDS =================
        // Adding summary metrics for consistency with the Dashboard
        content.add(createStatCard("Total Revenue", "₱ 45,200.00", 30, 70, new Color(34, 197, 94)));
        content.add(createStatCard("Pending Dues", "₱ 12,850.00", 250, 70, new Color(249, 115, 22)));
        content.add(createStatCard("Transactions", "128", 470, 70, new Color(79, 70, 229)));

        // ================= TRANSACTION TABLE =================
        JLabel tableLabel = new JLabel("Recent Transactions");
        tableLabel.setBounds(30, 200, 200, 25);
        tableLabel.setFont(new Font("Arial", Font.BOLD, 16));
        content.add(tableLabel);

        String[] cols = {"ID", "Customer", "Date", "Amount", "Status", "Method"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        model.addRow(new Object[]{"#TR-101", "John Doe", "2026-04-28", "₱ 1,500.00", "Paid", "GCash"});
        model.addRow(new Object[]{"#TR-102", "Jane Smith", "2026-04-29", "₱ 3,200.00", "Pending", "Cash"});
        
        JTable table = new JTable(model);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBounds(30, 235, 880, 400);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        content.add(scroll);

        // ================= VISIBILITY FIX =================
        // Ensures content renders immediately in absolute layouts
        revalidate();
        repaint();
        setVisible(true);
    }

    private void navigateTo(String destination) {
        this.dispose();
        switch (destination) {
            case "Dashboard": new Dashboard(); break;
            case "Rentals": new Rentals(); break;
            case "Inventory": new Inventory(); break;
            case "Customers": new Customers(); break;
            case "Payments": new Payments(); break;
            case "Settings": new Settings(); break;
        }
    }

    // Helper to create metric cards consistent with your Dashboard design[cite: 1]
    private JPanel createStatCard(String title, String val, int x, int y, Color accent) {
        JPanel card = new JPanel();
        card.setLayout(null);
        card.setBounds(x, y, 200, 100);
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createMatteBorder(0, 4, 0, 0, accent));

        JLabel t = new JLabel(title);
        t.setBounds(15, 15, 150, 20);
        t.setForeground(Color.GRAY);
        
        JLabel v = new JLabel(val);
        v.setBounds(15, 45, 170, 30);
        v.setFont(new Font("Arial", Font.BOLD, 18));

        card.add(t); card.add(v);
        return card;
    }
}