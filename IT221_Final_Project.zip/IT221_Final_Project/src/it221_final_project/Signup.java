package it221_final_project;

import javax.swing.*;
import java.awt.*;

public class Signup extends JFrame {

    private JTextField firstName, lastName, business, email;
    private JPasswordField password, confirmPassword;

        public Signup() {
        setTitle("Sign Up");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        createUI();
    }
    

    private void createUI() {

        // FRAME SETTINGS
        setTitle("Sign Up | EventRides PH");
        setSize(500, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(248, 250, 252));

        // CARD PANEL
        JPanel card = new JPanel();
        card.setLayout(null);
        card.setBounds(50, 30, 380, 550);
        card.setBackground(Color.WHITE);
        add(card);

        // TITLE
        JLabel title = new JLabel("Create Account", SwingConstants.CENTER);
        title.setBounds(0, 20, 380, 30);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(new Color(79, 70, 229));
        card.add(title);

        // FIRST NAME
        JLabel fn = new JLabel("First Name");
        fn.setBounds(30, 70, 150, 20);
        card.add(fn);

        firstName = new JTextField();
        firstName.setBounds(30, 90, 150, 35);
        card.add(firstName);

        // LAST NAME
        JLabel ln = new JLabel("Last Name");
        ln.setBounds(200, 70, 150, 20);
        card.add(ln);

        lastName = new JTextField();
        lastName.setBounds(200, 90, 150, 35);
        card.add(lastName);

        // BUSINESS
        JLabel bus = new JLabel("Business Name");
        bus.setBounds(30, 140, 300, 20);
        card.add(bus);

        business = new JTextField();
        business.setBounds(30, 160, 320, 35);
        card.add(business);

        // EMAIL
        JLabel em = new JLabel("Email");
        em.setBounds(30, 210, 300, 20);
        card.add(em);

        email = new JTextField();
        email.setBounds(30, 230, 320, 35);
        card.add(email);

        // PASSWORD
        JLabel pass = new JLabel("Password");
        pass.setBounds(30, 280, 300, 20);
        card.add(pass);

        password = new JPasswordField();
        password.setBounds(30, 300, 320, 35);
        card.add(password);

        // CONFIRM PASSWORD
        JLabel confirm = new JLabel("Confirm Password");
        confirm.setBounds(30, 350, 300, 20);
        card.add(confirm);

        confirmPassword = new JPasswordField();
        confirmPassword.setBounds(30, 370, 320, 35);
        card.add(confirmPassword);

        // ERROR LABEL
        JLabel error = new JLabel("");
        error.setBounds(30, 410, 300, 20);
        error.setForeground(Color.RED);
        card.add(error);

        // BUTTON
        JButton signupBtn = new JButton("Get Started");
        signupBtn.setBounds(30, 440, 320, 45);
        signupBtn.setBackground(new Color(79, 70, 229));
        signupBtn.setForeground(Color.WHITE);
        signupBtn.setFocusPainted(false);
        card.add(signupBtn);
        
        //BACK BUTTONS
        JButton backLoginBtn = new JButton("← Back to Login");
        backLoginBtn.setBounds(30, 480, 150, 30);
        backLoginBtn.setFocusPainted(false);
        backLoginBtn.setForeground(new Color(79, 70, 229));
        backLoginBtn.setBackground(Color.WHITE);
        card.add(backLoginBtn);

        JButton backIndexBtn = new JButton("🏠 Home");
        backIndexBtn.setBounds(200, 480, 150, 30);
        backIndexBtn.setFocusPainted(false);
        backIndexBtn.setForeground(new Color(79, 70, 229));
        backIndexBtn.setBackground(Color.WHITE);
        card.add(backIndexBtn);

        // ACTION
        signupBtn.addActionListener(e -> {
        String pass1 = new String(password.getPassword());
        String pass2 = new String(confirmPassword.getPassword());

        if (firstName.getText().isEmpty() || lastName.getText().isEmpty()
                || business.getText().isEmpty() || email.getText().isEmpty()
                || pass1.isEmpty() || pass2.isEmpty()) {
            error.setText("Please fill all fields!");
            return;
        }

        if (!pass1.equals(pass2)) {
            error.setText("Passwords do not match!");
            return;
        }

        error.setText("");

        signupBtn.setText("Creating account...");
        signupBtn.setEnabled(false);

        Timer t = new Timer(1500, ev -> {
            JOptionPane.showMessageDialog(this, "Account Created Successfully!");

            // AFTER SIGNUP → GO TO LOGIN (recommended flow)
            new Login();
            dispose();
        });

        t.setRepeats(false);
        t.start();
    });
        
            // GO BACK TO LOGIN
            backLoginBtn.addActionListener(e -> {
                new Login();
                dispose();
            });

            // GO BACK TO INDEX
            backIndexBtn.addActionListener(e -> {
                new Index();
                dispose();
            });
            
        setVisible(true);
    }
}