package it221_final_project;

import javax.swing.*;
import java.awt.*;

public class Index extends JFrame {

    public Index() {
        initUI();
    }

    private void initUI() {
        setTitle("EventRides PH | Smart Rental Management");
        setSize(1100, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(createNavbar(), BorderLayout.NORTH);
        add(createHeroSection(), BorderLayout.CENTER);
        add(createFooter(), BorderLayout.SOUTH);

        setVisible(true); // ✅ FIXED (was wrongly inside styleButton)
    }

    // ================= NAVBAR =================
    private JPanel createNavbar() {
        JPanel nav = new JPanel(new BorderLayout());
        nav.setBackground(Color.WHITE);
        nav.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel brand = new JLabel("🚗 EventRides PH");
        brand.setFont(new Font("Inter", Font.BOLD, 20));
        brand.setForeground(new Color(79, 70, 229));

        JPanel navLinks = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        navLinks.setBackground(Color.WHITE);

        JButton loginBtn = new JButton("Login");
        JButton signupBtn = new JButton("Sign Up");

        stylePrimary(loginBtn, false);
        stylePrimary(signupBtn, true);

        // NAVIGATION (MATCH HTML)
        loginBtn.addActionListener(e -> {
            dispose();
            new Login().setVisible(true);
        });

        signupBtn.addActionListener(e -> {
            dispose();
            new Signup().setVisible(true);
        });

        navLinks.add(loginBtn);
        navLinks.add(signupBtn);

        nav.add(brand, BorderLayout.WEST);
        nav.add(navLinks, BorderLayout.EAST);

        return nav;
    }

    // ================= HERO SECTION =================
    private JPanel createHeroSection() {
        JPanel hero = new JPanel(new GridLayout(1, 2));
        hero.setBackground(new Color(248, 250, 252));
        hero.setBorder(BorderFactory.createEmptyBorder(60, 60, 60, 60));

        // LEFT SIDE
        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setBackground(new Color(248, 250, 252));

        JLabel badge = new JLabel("⭐ Trusted by local event organizers");
        badge.setForeground(new Color(79, 70, 229));

        JLabel title = new JLabel("<html><h1>Simplify Your Event Rentals with EventRides PH</h1></html>");
        JLabel subtitle = new JLabel("<html>Avoid double bookings and track inventory in real-time. Manage vehicles, tables, and chairs with ease using our smart rental dashboard.</html>");

        JButton getStarted = new JButton("Get Started");
        JButton login = new JButton("Login to Dashboard");

        stylePrimary(getStarted, true);
        stylePrimary(login, false);

        getStarted.addActionListener(e -> {
            dispose();
            new Signup().setVisible(true);
        });

        login.addActionListener(e -> {
            dispose();
            new Login().setVisible(true);
        });

        left.add(badge);
        left.add(Box.createVerticalStrut(10));
        left.add(title);
        left.add(Box.createVerticalStrut(10));
        left.add(subtitle);
        left.add(Box.createVerticalStrut(20));
        left.add(getStarted);
        left.add(Box.createVerticalStrut(10));
        left.add(login);

        // RIGHT MOCKUP (HTML DASHBOARD PREVIEW STYLE)
        JPanel right = new JPanel();
        right.setBackground(Color.WHITE);
        right.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 2));

        right.setLayout(new GridLayout(4, 1, 10, 10));

        right.add(mockCard("Active Bookings", "24", new Color(79, 70, 229)));
        right.add(mockCard("Revenue", "₱12,500", new Color(34, 197, 94)));
        right.add(mockCard("Missed Bookings", "0", new Color(239, 68, 68)));
        right.add(mockCard("Inventory Status", "Good", new Color(59, 130, 246)));

        hero.add(left);
        hero.add(right);

        return hero;
    }

    // ================= FOOTER =================
    private JPanel createFooter() {
        JPanel footer = new JPanel();
        footer.setBackground(Color.WHITE);

        JLabel text = new JLabel("© 2026 EventRides PH - All rights reserved");
        footer.add(text);

        return footer;
    }

    // ================= BUTTON STYLE =================
    private void stylePrimary(JButton btn, boolean primary) {
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(180, 40));

        if (primary) {
            btn.setBackground(new Color(79, 70, 229));
            btn.setForeground(Color.WHITE);
        } else {
            btn.setBackground(Color.WHITE);
            btn.setForeground(new Color(79, 70, 229));
            btn.setBorder(BorderFactory.createLineBorder(new Color(79, 70, 229)));
        }
    }

    // ================= MOCK DASHBOARD CARD =================
    private JPanel mockCard(String title, String value, Color color) {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(248, 250, 252));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setLayout(new GridLayout(2, 1));

        JLabel t = new JLabel(title);
        JLabel v = new JLabel(value);

        v.setFont(new Font("Arial", Font.BOLD, 18));
        v.setForeground(color);

        panel.add(t);
        panel.add(v);

        return panel;
    }
}