package it221_final_project;

import javax.swing.*;
import java.awt.*;

public class Inventory extends JFrame {

    public Inventory() {
        createUI();
    }

    private void createUI() {
        // ================= FRAME CONFIGURATION =================
        setTitle("EventRides PH | Item Management");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null); 
        
        // Setting background on the content pane directly
        getContentPane().setBackground(new Color(223, 232, 242));

        // ================= SIDEBAR =================
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setBounds(0, 0, 260, 700);
        sidebar.setBackground(new Color(15, 23, 42));
        add(sidebar);

        JLabel brand = new JLabel("EventRides PH");
        brand.setBounds(20, 30, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Arial", Font.BOLD, 18));
        sidebar.add(brand);

        String[] menu = {"Dashboard", "Rentals", "Inventory", "Customers", "Payments", "Settings"};
        int y = 100;

        for (String item : menu) {
            JButton btn = new JButton(item);
            btn.setBounds(20, y, 200, 40);
            btn.setFocusPainted(false);
            btn.setBackground(new Color(30, 41, 59));
            btn.setForeground(Color.WHITE);

            if (item.equals("Inventory")) {
                btn.setBackground(new Color(79, 70, 229));
            }

            btn.addActionListener(e -> navigateTo(btn.getText()));
            sidebar.add(btn);
            y += 50;
        }

        // ================= MAIN CONTENT AREA =================
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBounds(260, 0, 940, 700);
        content.setBackground(new Color(223, 232, 242));
        add(content);

        // HEADER
        JLabel title = new JLabel("Item Management");
        title.setBounds(30, 20, 300, 30);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        content.add(title);

        // ================= FILTER BAR =================
        JTextField search = new JTextField("Search item...");
        search.setBounds(30, 70, 250, 35);
        content.add(search);

        JButton btnAll = new JButton("All");
        btnAll.setBounds(290, 70, 80, 35);
        content.add(btnAll);

        JButton btnVehicles = new JButton("Vehicles");
        btnVehicles.setBounds(380, 70, 100, 35);
        content.add(btnVehicles);

        // ================= VEHICLE GRID =================
        JLabel vehicleLabel = new JLabel("Vehicles");
        vehicleLabel.setBounds(30, 130, 200, 25);
        vehicleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        content.add(vehicleLabel);

        int cardX = 30;
        for (int i = 1; i <= 4; i++) {
            content.add(createItemCard("Vehicle " + i, "₱ 1,500/day", cardX, 160));
            cardX += 220;
        }

        // ================= EQUIPMENT LIST =================
        JLabel equipLabel = new JLabel("Equipment");
        equipLabel.setBounds(30, 350, 200, 25);
        equipLabel.setFont(new Font("Arial", Font.BOLD, 16));
        content.add(equipLabel);

        int rowY = 385;
        String[] gear = {"Monoblock Chair", "Buffet Table", "Sound System", "Tent (3x3)"};
        for (String name : gear) {
            content.add(createItemRow(name, rowY));
            rowY += 60;
        }

        // IMPORTANT: Refresh the frame to ensure content shows up
        revalidate();
        repaint();
        setVisible(true);
    }

    private void navigateTo(String destination) {
        this.dispose();
        switch (destination) {
            case "Dashboard": new Dashboard(); break;
            case "Rentals": new Rentals(); break;
            case "Inventory": new Inventory(); break;
            case "Customers": new Customers(); break;
            case "Payments": new Payments(); break;
            case "Settings": new Settings(); break;
        }
    }

    private JPanel createItemCard(String name, String price, int x, int y) {
        JPanel card = new JPanel();
        card.setLayout(null);
        card.setBounds(x, y, 200, 160);
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230)));

        JLabel n = new JLabel(name);
        n.setBounds(15, 15, 170, 20);
        n.setFont(new Font("Arial", Font.BOLD, 14));

        JLabel p = new JLabel(price);
        p.setBounds(15, 40, 170, 20);
        p.setForeground(new Color(34, 197, 94));

        JButton edit = new JButton("Edit");
        edit.setBounds(15, 110, 80, 30);
        
        JButton del = new JButton("Delete");
        del.setBounds(105, 110, 80, 30);

        card.add(n); card.add(p); card.add(edit); card.add(del);
        return card;
    }

    private JPanel createItemRow(String name, int y) {
        JPanel row = new JPanel();
        row.setLayout(null);
        row.setBounds(30, y, 880, 50);
        row.setBackground(Color.WHITE);
        row.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230)));

        JLabel n = new JLabel(name);
        n.setBounds(20, 15, 300, 20);
        
        JButton edit = new JButton("Edit");
        edit.setBounds(700, 10, 75, 30);
        
        JButton del = new JButton("Delete");
        del.setBounds(785, 10, 75, 30);

        row.add(n); row.add(edit); row.add(del);
        return row;
    }
}