package it221_final_project;

import javax.swing.*;
import java.awt.*;

public class Dashboard extends JFrame {

    public Dashboard() {
        createUI();
    }

    private void createUI() {

        // ================= FRAME =================
        setTitle("EventRides PH | Premium Dashboard");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(223, 232, 242));

        // ================= SIDEBAR =================
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setBounds(0, 0, 260, 700);
        sidebar.setBackground(new Color(15, 23, 42));
        add(sidebar);

        JLabel brand = new JLabel("EventRides PH");
        brand.setBounds(20, 30, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Arial", Font.BOLD, 18));
        sidebar.add(brand);

        String[] menu = {"Dashboard", "Rentals", "Inventory", "Customers", "Payments", "Settings"};
        int y = 100;

        for (String item : menu) {
            JButton btn = new JButton(item);
            btn.setBounds(20, y, 200, 40);
            btn.setFocusPainted(false);
            btn.setBackground(new Color(30, 41, 59));
            btn.setForeground(Color.WHITE);

            // Connectivity Function
            btn.addActionListener(e -> {
                String choice = btn.getText();
                navigateTo(choice);
            });

            sidebar.add(btn);
            y += 50;
        }

        // ================= MAIN CONTENT =================
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBounds(260, 0, 940, 700);
        content.setBackground(new Color(223, 232, 242));
        add(content);

        // ================= HEADER =================
        JLabel title = new JLabel("Quick Overview");
        title.setBounds(30, 20, 300, 30);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        content.add(title);

        // ================= STATS =================
        content.add(createStatCard("Total Bookings", "0", 30, 80, new Color(79, 70, 229)));
        content.add(createStatCard("Revenue", "₱0", 250, 80, new Color(34, 197, 94)));
        content.add(createStatCard("Active Now", "0", 470, 80, new Color(234, 179, 8)));
        content.add(createStatCard("Overdue", "0", 690, 80, new Color(239, 68, 68)));

        // ================= TABLE =================
        JLabel tableLabel = new JLabel("Recent Transactions");
        tableLabel.setBounds(30, 260, 300, 20);
        tableLabel.setFont(new Font("Arial", Font.BOLD, 16));
        content.add(tableLabel);

        String[][] data = {
                {"No Data", "-", "-", "-", "-"}
        };

        String[] cols = {"Rental ID", "Item", "Client", "Status", "Return Date"};

        JTable table = new JTable(data, cols);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBounds(30, 290, 880, 120);
        content.add(scroll);

        // ================= CALENDAR (SIMPLIFIED) =================
        JPanel calendar = new JPanel();
        calendar.setLayout(new GridLayout(5, 7));
        calendar.setBounds(30, 430, 600, 200);

        for (int i = 1; i <= 35; i++) {
            JLabel day = new JLabel(String.valueOf(i), SwingConstants.CENTER);
            day.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
            calendar.add(day);
        }

        content.add(calendar);

        // ================= EMPTY SCHEDULE =================
        JLabel schedule = new JLabel("No rentals scheduled for today");
        schedule.setBounds(660, 430, 300, 30);
        schedule.setFont(new Font("Arial", Font.PLAIN, 14));
        content.add(schedule);

        setVisible(true);
    }
    
    // Add this helper method to the Dashboard class
    private void navigateTo(String destination) {
        this.dispose(); // Close current frame
            switch (destination) {
                case "Dashboard": new Dashboard(); break;
                case "Rentals": new Rentals(); break;
                case "Inventory": new Inventory(); break;
                case "Customers": new Customers(); break;
                case "Payments": new Payments(); break;
                case "Settings": new Settings(); break;
            }
    }


    // ================= STAT CARD METHOD =================
    private JPanel createStatCard(String title, String value, int x, int y, Color color) {

        JPanel card = new JPanel();
        card.setLayout(null);
        card.setBounds(x, y, 200, 120);
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(238, 242, 246)));

        JLabel t = new JLabel(title);
        t.setBounds(15, 15, 180, 20);
        t.setForeground(Color.GRAY);

        JLabel v = new JLabel(value);
        v.setBounds(15, 50, 180, 30);
        v.setFont(new Font("Arial", Font.BOLD, 24));
        v.setForeground(color);

        card.add(t);
        card.add(v);

        return card;
    }

    static class setVisible {

        public setVisible(boolean b) {
        }
    }

}

