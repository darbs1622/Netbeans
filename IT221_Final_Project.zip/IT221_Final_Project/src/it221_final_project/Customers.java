package it221_final_project;

import javax.swing.*;
import java.awt.*;

public class Customers extends JFrame {

    public Customers() {
        createUI();
    }

    private void createUI() {

        // ================= FRAME CONFIGURATION =================
        // Matches the Dashboard.java dimensions and layout
        setTitle("EventRides PH | Customer Management");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null); 
        getContentPane().setBackground(new Color(223, 232, 242));

        // ================= SIDEBAR =================
        // Uses the exact bounds and color from Dashboard.java
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setBounds(0, 0, 260, 700);
        sidebar.setBackground(new Color(15, 23, 42));
        add(sidebar);

        JLabel brand = new JLabel("EventRides PH");
        brand.setBounds(20, 30, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Arial", Font.BOLD, 18));
        sidebar.add(brand);

        String[] menu = {"Dashboard", "Rentals", "Inventory", "Customers", "Payments", "Settings"};
        int y = 100;

        for (String item : menu) {
            JButton btn = new JButton(item);
            btn.setBounds(20, y, 200, 40);
            btn.setFocusPainted(false);
            btn.setBackground(new Color(30, 41, 59));
            btn.setForeground(Color.WHITE);

            btn.addActionListener(e -> {
                String choice = btn.getText();
                navigateTo(choice);
            });

            sidebar.add(btn);
            y += 50;
        }

        // ================= MAIN CONTENT AREA =================
        // Positioned at x=260 to sit next to the sidebar[cite: 1]
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBounds(260, 0, 940, 700);
        content.setBackground(new Color(223, 232, 242));
        add(content);

        // ================= HEADER =================
        JLabel title = new JLabel("Customer Management");
        title.setBounds(30, 20, 300, 30);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        content.add(title);

        // ================= STAT CARDS =================
        // Using the same Stat Card helper logic as Dashboard[cite: 1]
        content.add(createStatCard("Total Clients", "0", 30, 80, new Color(79, 70, 229)));
        content.add(createStatCard("New this Month", "0", 250, 80, new Color(34, 197, 94)));
        content.add(createStatCard("Avg. Value", "₱0", 470, 80, new Color(234, 179, 8)));
        content.add(createStatCard("Retention", "0%", 690, 80, new Color(239, 68, 68)));

        // ================= CUSTOMER TABLE =================
        JLabel tableLabel = new JLabel("Customer Directory");
        tableLabel.setBounds(30, 260, 300, 20);
        tableLabel.setFont(new Font("Arial", Font.BOLD, 16));
        content.add(tableLabel);

        String[] cols = {"Customer ID", "Full Name", "Contact", "Total Rentals", "Status"};
        String[][] data = {{"-", "-", "-", "-", "-"}};

        JTable table = new JTable(data, cols);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBounds(30, 290, 880, 300); // Increased height for better visibility
        content.add(scroll);

        setVisible(true);
    }

    // Navigation logic consistent with Dashboard[cite: 1]
    private void navigateTo(String destination) {
        this.dispose();
        switch (destination) {
            case "Dashboard": new Dashboard(); break;
            case "Rentals":   new Rentals(); break;
            case "Inventory": new Inventory(); break;
            case "Customers": new Customers(); break;
            case "Payments":  new Payments(); break;
            case "Settings":  new Settings(); break;
        }
    }

    // Helper method copied from Dashboard for visual consistency[cite: 1]
    private JPanel createStatCard(String title, String value, int x, int y, Color color) {
        JPanel card = new JPanel();
        card.setLayout(null);
        card.setBounds(x, y, 200, 120);
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(238, 242, 246)));

        JLabel t = new JLabel(title);
        t.setBounds(15, 15, 180, 20);
        t.setForeground(Color.GRAY);

        JLabel v = new JLabel(value);
        v.setBounds(15, 50, 180, 30);
        v.setFont(new Font("Arial", Font.BOLD, 24));
        v.setForeground(color);

        card.add(t);
        card.add(v);

        return card;
    }
}