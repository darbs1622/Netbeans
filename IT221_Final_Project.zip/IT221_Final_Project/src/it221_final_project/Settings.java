package it221_final_project;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class Settings extends JFrame {

    public Settings() {
        createUI();
    }

    private void createUI() {
        // ================= FRAME CONFIGURATION =================
        // Matches the standard dimensions and layout of Dashboard.java
        setTitle("EventRides PH | Settings");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        getContentPane().setBackground(new Color(223, 232, 242));

        // ================= SIDEBAR =================
        // Standardized width of 260px and background from Dashboard.java
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setBounds(0, 0, 260, 700);
        sidebar.setBackground(new Color(15, 23, 42));
        add(sidebar);

        JLabel brand = new JLabel("EventRides PH");
        brand.setBounds(20, 30, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Arial", Font.BOLD, 18));
        sidebar.add(brand);

        String[] menu = {"Dashboard", "Rentals", "Inventory", "Customers", "Payments", "Settings"};
        int y = 100;

        for (String item : menu) {
            JButton btn = new JButton(item);
            btn.setBounds(20, y, 200, 40);
            btn.setFocusPainted(false);
            btn.setBackground(new Color(30, 41, 59));
            btn.setForeground(Color.WHITE);

            // Highlight "Settings" as the active page
            if (item.equals("Settings")) {
                btn.setBackground(new Color(79, 70, 229));
            }

            btn.addActionListener(e -> navigateTo(btn.getText()));
            sidebar.add(btn);
            y += 50;
        }

        // ================= MAIN CONTENT AREA =================
        // Positioned at x=260 to sit flush with the sidebar
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBounds(260, 0, 940, 700);
        content.setBackground(new Color(223, 232, 242));
        add(content);

        // HEADER
        JLabel title = new JLabel("System Settings");
        title.setBounds(30, 20, 300, 30);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        content.add(title);

        JLabel subtitle = new JLabel("Manage account preferences and business settings");
        subtitle.setBounds(30, 50, 400, 20);
        subtitle.setForeground(Color.GRAY);
        content.add(subtitle);

        // ================= PROFILE CARD =================
        JPanel profileCard = createCardPanel("Profile Information");
        profileCard.setBounds(30, 90, 430, 230);
        profileCard.setLayout(null);

        JLabel nameLabel = new JLabel("Full Name:");
        nameLabel.setBounds(20, 30, 100, 20);
        JTextField nameField = new JTextField();
        nameField.setBounds(120, 30, 280, 25);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(20, 70, 100, 20);
        JTextField emailField = new JTextField();
        emailField.setBounds(120, 70, 280, 25);

        JButton updateBtn = new JButton("Update Profile");
        updateBtn.setBounds(250, 180, 150, 30);
        updateBtn.setBackground(new Color(30, 41, 59));
        updateBtn.setForeground(Color.WHITE);

        profileCard.add(nameLabel);
        profileCard.add(nameField);
        profileCard.add(emailLabel);
        profileCard.add(emailField);
        profileCard.add(updateBtn);
        content.add(profileCard);

        // ================= BUSINESS CARD =================
        JPanel businessCard = createCardPanel("Business Details");
        businessCard.setBounds(480, 90, 430, 230);
        businessCard.setLayout(null);

        JTextField bName = new JTextField("EventRides PH");
        bName.setBounds(20, 40, 390, 30);
        JTextField address = new JTextField("Main Office Address");
        address.setBounds(20, 80, 390, 30);
        
        JButton saveBtn = new JButton("Save Business Data");
        saveBtn.setBounds(230, 180, 180, 30);
        saveBtn.setBackground(new Color(79, 70, 229));
        saveBtn.setForeground(Color.WHITE);

        businessCard.add(bName);
        businessCard.add(address);
        businessCard.add(saveBtn);
        content.add(businessCard);

        // ================= SECURITY =================
        JPanel securityCard = createCardPanel("Security");
        securityCard.setBounds(30, 340, 300, 220);
        securityCard.setLayout(null);

        JPasswordField newPass = new JPasswordField();
        newPass.setBorder(BorderFactory.createTitledBorder("New Password"));
        newPass.setBounds(20, 40, 260, 45);
        
        JButton passBtn = new JButton("Update Password");
        passBtn.setBounds(50, 160, 200, 35);
        
        securityCard.add(newPass);
        securityCard.add(passBtn);
        content.add(securityCard);

        // ================= PREFERENCES =================
        JPanel prefCard = createCardPanel("Preferences");
        prefCard.setBounds(350, 340, 280, 220);
        prefCard.setLayout(new GridLayout(4, 1));
        prefCard.add(new JCheckBox("Enable Notifications", true));
        prefCard.add(new JCheckBox("Auto Backup", true));
        content.add(prefCard);

        // ================= DATA MANAGEMENT =================
        JPanel dataCard = createCardPanel("Data Management");
        dataCard.setBounds(650, 340, 260, 220);
        dataCard.setLayout(new GridLayout(3, 1, 5, 10));

        JButton backup = new JButton("Download Backup");
        JButton wipe = new JButton("Wipe Data");
        wipe.setBackground(new Color(239, 68, 68)); // Matching Dashboard Overdue color[cite: 1]
        wipe.setForeground(Color.WHITE);

        dataCard.add(backup);
        dataCard.add(wipe);
        content.add(dataCard);

        setVisible(true);
    }

    // Standardized Navigation helper[cite: 1]
    private void navigateTo(String destination) {
        this.dispose();
        switch (destination) {
            case "Dashboard": new Dashboard(); break;
            case "Rentals": new Rentals(); break;
            case "Inventory": new Inventory(); break;
            case "Customers": new Customers(); break;
            case "Payments": new Payments(); break;
            case "Settings": new Settings(); break;
        }
    }

    private JPanel createCardPanel(String title) {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(238, 242, 246)), title));
        return panel;
    }
}