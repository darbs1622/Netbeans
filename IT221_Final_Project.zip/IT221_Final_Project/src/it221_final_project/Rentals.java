package it221_final_project;

import javax.swing.*;
import java.awt.*;

public class Rentals extends JFrame {

    public Rentals() {
        createUI();
    }

    private void createUI() {
        // ================= FRAME CONFIGURATION =================
        // Matches the Dashboard.java dimensions and layout
        setTitle("EventRides PH | Rental Management");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null); 
        getContentPane().setBackground(new Color(223, 232, 242));

        // ================= SIDEBAR =================
        // Uses exact bounds, colors, and font from Dashboard.java
        JPanel sidebar = new JPanel();
        sidebar.setLayout(null);
        sidebar.setBounds(0, 0, 260, 700);
        sidebar.setBackground(new Color(15, 23, 42));
        add(sidebar);

        JLabel brand = new JLabel("EventRides PH");
        brand.setBounds(20, 30, 200, 30);
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("Arial", Font.BOLD, 18));
        sidebar.add(brand);

        String[] menu = {"Dashboard", "Rentals", "Inventory", "Customers", "Payments", "Settings"};
        int y = 100;

        for (String item : menu) {
            JButton btn = new JButton(item);
            btn.setBounds(20, y, 200, 40);
            btn.setFocusPainted(false);
            btn.setBackground(new Color(30, 41, 59));
            btn.setForeground(Color.WHITE);

            btn.addActionListener(e -> {
                String choice = btn.getText();
                navigateTo(choice);
            });

            sidebar.add(btn);
            y += 50;
        }

        // ================= MAIN CONTENT AREA =================
        // Content panel shifted by sidebar width (260)[cite: 1]
        JPanel content = new JPanel();
        content.setLayout(null);
        content.setBounds(260, 0, 940, 700);
        content.setBackground(new Color(223, 232, 242));
        add(content);

        // ================= HEADER =================
        JLabel title = new JLabel("Rental Management");
        title.setBounds(30, 20, 300, 30);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        content.add(title);

        // ================= TOP CONTROLS (SEARCH & FILTER) =================
        JTextField search = new JTextField("Search item...");
        search.setBounds(30, 70, 200, 30);
        content.add(search);

        JButton btnAll = new JButton("All");
        btnAll.setBounds(240, 70, 80, 30);
        content.add(btnAll);

        JButton btnVehicles = new JButton("Vehicles");
        btnVehicles.setBounds(330, 70, 100, 30);
        content.add(btnVehicles);

        // ================= INVENTORY PANEL =================
        JPanel inventoryPanel = new JPanel();
        inventoryPanel.setLayout(null);
        inventoryPanel.setBounds(30, 120, 430, 500);
        inventoryPanel.setBackground(Color.WHITE);
        inventoryPanel.setBorder(BorderFactory.createTitledBorder("Available Inventory"));
        
        JLabel emptyInv = new JLabel("No items available", SwingConstants.CENTER);
        emptyInv.setBounds(0, 200, 430, 30);
        emptyInv.setForeground(Color.GRAY);
        inventoryPanel.add(emptyInv);
        
        content.add(inventoryPanel);

        // ================= SUMMARY PANEL =================
        JPanel summaryPanel = new JPanel();
        summaryPanel.setLayout(null);
        summaryPanel.setBounds(480, 120, 430, 500);
        summaryPanel.setBackground(Color.WHITE);
        summaryPanel.setBorder(BorderFactory.createTitledBorder("Rental Summary"));

        JLabel sumTitle = new JLabel("Booking Details");
        sumTitle.setBounds(20, 30, 200, 20);
        sumTitle.setFont(new Font("Arial", Font.BOLD, 14));
        summaryPanel.add(sumTitle);

        JLabel tax = new JLabel("Tax: ₱0.00");
        tax.setBounds(20, 380, 200, 20);
        summaryPanel.add(tax);

        JLabel total = new JLabel("Total: ₱0.00");
        total.setBounds(20, 410, 200, 30);
        total.setFont(new Font("Arial", Font.BOLD, 18));
        summaryPanel.add(total);

        JButton confirm = new JButton("Confirm Booking");
        confirm.setBounds(20, 450, 390, 40);
        confirm.setBackground(new Color(79, 70, 229));
        confirm.setForeground(Color.WHITE);
        summaryPanel.add(confirm);

        content.add(summaryPanel);

        setVisible(true);
    }

    // Navigation logic consistent with Dashboard[cite: 1]
    private void navigateTo(String destination) {
        this.dispose();
        switch (destination) {
            case "Dashboard": new Dashboard(); break;
            case "Rentals": new Rentals(); break;
            case "Inventory": new Inventory(); break;
            case "Customers": new Customers(); break;
            case "Payments": new Payments(); break;
            case "Settings": new Settings(); break;
        }
    }
}